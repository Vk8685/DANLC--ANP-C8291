a=int(input("Enter the Basic Salary: "))
print("Bonus of bacic salary is: ",(a/10))
