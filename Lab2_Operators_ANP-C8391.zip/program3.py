#  Wap to check whether an year is leap or not
a=int(input("Enter the year :"))
result= "This year is leap year" if (a%4==0 and a%100==0 and a%400==0 or a%4==0 and a%100!=0
                                     and a%400!=0) else "This year is not a leap year"
print(result)